package com.example.drivepdf

import android.view.View
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

object Exec {
    val io: ExecutorService = Executors.newCachedThreadPool()
}

fun View.fadeTo(show: Boolean, duration: Long = 150L) {
    animate().cancel()
    if (show) {
        visibility = View.VISIBLE
        animate().alpha(1f).setDuration(duration).start()
    } else if (visibility == View.VISIBLE) {
        animate().alpha(0f).setDuration(duration).withEndAction { visibility = View.GONE }.start()
    }
}
