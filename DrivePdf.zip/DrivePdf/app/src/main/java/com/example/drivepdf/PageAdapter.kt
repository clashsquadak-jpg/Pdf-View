package com.example.drivepdf

import android.graphics.Bitmap
import android.graphics.Color
import android.util.LruCache
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.ExecutorService
import java.util.concurrent.Future
import kotlin.math.min

class PageAdapter(
    private val doc: PdfDoc,
    itemWidth: Int,
    private val sideMargin: Int,
    private val vMargin: Int,
    private val exec: ExecutorService
) : RecyclerView.Adapter<PageAdapter.VH>() {

    class VH(val img: ImageView) : RecyclerView.ViewHolder(img) {
        var task: Future<*>? = null
        var index = -1
    }

    private val cache = object : LruCache<Int, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 4).toInt()
    ) {
        override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
    }

    private val contentWidth = itemWidth - 2 * sideMargin
    private val renderWidth = min(contentWidth * 2, 2000)

    override fun getItemCount() = doc.pageCount

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val iv = ImageView(parent.context)
        iv.scaleType = ImageView.ScaleType.FIT_XY
        iv.setBackgroundColor(Color.WHITE)
        return VH(iv)
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val size = doc.sizes[position]
        val ratio = if (size[0] > 0) size[1].toFloat() / size[0] else 1.414f
        val lp = RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            (contentWidth * ratio).toInt()
        )
        lp.setMargins(sideMargin, vMargin, sideMargin, vMargin)
        h.img.layoutParams = lp

        h.task?.cancel(false)
        h.index = position
        val cached = cache.get(position)
        if (cached != null) {
            h.img.setImageBitmap(cached)
        } else {
            h.img.setImageDrawable(null)
            h.task = exec.submit {
                try {
                    val bmp = doc.render(position, renderWidth)
                    cache.put(position, bmp)
                    h.img.post { if (h.index == position) h.img.setImageBitmap(bmp) }
                } catch (_: Exception) {
                }
            }
        }
    }

    override fun onViewRecycled(h: VH) {
        h.task?.cancel(false)
        h.index = -1
        h.img.setImageDrawable(null)
    }
}
