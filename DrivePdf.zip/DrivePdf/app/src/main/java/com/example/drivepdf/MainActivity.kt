package com.example.drivepdf

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.provider.OpenableColumns
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.doOnLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var toolbar: MaterialToolbar
    private lateinit var recycler: ZoomRecyclerView
    private lateinit var pill: TextView
    private lateinit var progress: View
    private lateinit var empty: View

    private val io = Executors.newSingleThreadExecutor()
    private val renderer = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private val hidePill = Runnable { pill.animate().alpha(0f).setDuration(300).start() }

    private var doc: PdfDoc? = null
    private var file: File? = null
    private var fileName = ""
    private var barsVisible = true

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) openUri(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        toolbar = findViewById(R.id.toolbar)
        recycler = findViewById(R.id.recycler)
        pill = findViewById(R.id.pill)
        progress = findViewById(R.id.progress)
        empty = findViewById(R.id.empty)

        toolbar.setNavigationOnClickListener { finish() }
        toolbar.menu.add(0, 1, 0, "Go to page")
        toolbar.menu.add(0, 2, 1, "Share")
        toolbar.menu.add(0, 3, 2, "Print")
        toolbar.menu.add(0, 4, 3, "Open another file")
        toolbar.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> goToPage()
                2 -> share()
                3 -> print()
                4 -> picker.launch(arrayOf("application/pdf"))
            }
            true
        }
        findViewById<View>(R.id.openButton).setOnClickListener {
            picker.launch(arrayOf("application/pdf"))
        }

        recycler.layoutManager = LinearLayoutManager(this)
        recycler.itemAnimator = null
        recycler.onTap = { toggleBars() }
        recycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                if (doc != null && dy != 0) {
                    updatePill()
                    showPill()
                }
            }
        })
        toolbar.post { recycler.setTopInset(toolbar.height) }

        val saved = savedInstanceState?.getString("path")
        if (saved != null && File(saved).exists()) {
            loadFile(
                File(saved),
                savedInstanceState.getString("name") ?: "document.pdf",
                savedInstanceState.getInt("page")
            )
        } else {
            handleIntent(intent)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        file?.let {
            outState.putString("path", it.absolutePath)
            outState.putString("name", fileName)
            outState.putInt("page", currentPage())
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        doc?.close()
        io.shutdownNow()
        renderer.shutdownNow()
    }

    // ---------- opening files ----------

    private fun handleIntent(i: Intent?) {
        val data = i?.data
        if (i?.action == Intent.ACTION_VIEW && data != null) openUri(data)
        else empty.visibility = View.VISIBLE
    }

    private fun openUri(uri: Uri) {
        progress.visibility = View.VISIBLE
        empty.visibility = View.GONE
        io.execute {
            try {
                val name = queryName(uri)
                val root = File(cacheDir, "pdfs")
                val dir = File(root, System.currentTimeMillis().toString()).apply { mkdirs() }
                val out = File(dir, name)
                contentResolver.openInputStream(uri)!!.use { input ->
                    out.outputStream().use { o -> input.copyTo(o) }
                }
                root.listFiles()?.filter { it != dir }?.forEach { it.deleteRecursively() }
                loadFileNow(out, name, 0)
            } catch (e: Exception) {
                fail("Couldn't open this file")
            }
        }
    }

    private fun queryName(uri: Uri): String {
        var name: String? = null
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) name = c.getString(0) }
        } catch (_: Exception) {
        }
        val raw = name?.takeIf { it.isNotBlank() } ?: uri.lastPathSegment ?: "document.pdf"
        var s = raw.substringAfterLast('/').replace(Regex("[\\\\:*?\"<>|]"), "_")
        if (!s.lowercase().endsWith(".pdf")) s += ".pdf"
        return s
    }

    private fun loadFile(f: File, name: String, page: Int) {
        progress.visibility = View.VISIBLE
        empty.visibility = View.GONE
        io.execute { loadFileNow(f, name, page) }
    }

    private fun loadFileNow(f: File, name: String, page: Int) {
        try {
            val d = PdfDoc(f)
            if (d.pageCount == 0) {
                d.close()
                fail("This PDF has no pages")
                return
            }
            runOnUiThread { show(d, f, name, page) }
        } catch (e: SecurityException) {
            fail("Password-protected PDFs aren't supported")
        } catch (e: Exception) {
            fail("Couldn't open this PDF")
        }
    }

    private fun fail(msg: String) = runOnUiThread {
        progress.visibility = View.GONE
        if (doc == null) empty.visibility = View.VISIBLE
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun show(d: PdfDoc, f: File, name: String, page: Int) {
        doc?.let { old ->
            recycler.adapter = null
            old.close()
        }
        doc = d
        file = f
        fileName = name
        toolbar.title = name
        progress.visibility = View.GONE
        empty.visibility = View.GONE
        recycler.resetZoom()
        recycler.doOnLayout {
            recycler.adapter = PageAdapter(d, recycler.width, dp(8), dp(4), renderer)
            (recycler.layoutManager as LinearLayoutManager)
                .scrollToPositionWithOffset(page.coerceIn(0, d.pageCount - 1), 0)
            updatePill()
            showPill()
        }
    }

    // ---------- UI helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun currentPage(): Int {
        val d = doc ?: return 0
        val lm = recycler.layoutManager as LinearLayoutManager
        var p = lm.findFirstVisibleItemPosition()
        if (p < 0) return 0
        val v = lm.findViewByPosition(p)
        if (v != null && v.bottom < recycler.height / recycler.scale * 0.4f && p < d.pageCount - 1) p++
        return p
    }

    private fun updatePill() {
        val d = doc ?: return
        pill.text = "${currentPage() + 1} / ${d.pageCount}"
    }

    private fun showPill() {
        handler.removeCallbacks(hidePill)
        pill.animate().alpha(1f).setDuration(100).start()
        handler.postDelayed(hidePill, 1500)
    }

    private fun toggleBars() {
        barsVisible = !barsVisible
        toolbar.animate()
            .translationY(if (barsVisible) 0f else -toolbar.height.toFloat())
            .alpha(if (barsVisible) 1f else 0f)
            .setDuration(200)
            .start()
    }

    // ---------- menu actions ----------

    private fun goToPage() {
        val d = doc ?: return
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "1 - ${d.pageCount}"
        }
        AlertDialog.Builder(this)
            .setTitle("Go to page")
            .setView(input)
            .setPositiveButton("Go") { _, _ ->
                input.text.toString().toIntOrNull()?.let { p ->
                    (recycler.layoutManager as LinearLayoutManager)
                        .scrollToPositionWithOffset((p - 1).coerceIn(0, d.pageCount - 1), 0)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun share() {
        val f = file ?: return
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val send = Intent(Intent.ACTION_SEND)
            .setType("application/pdf")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(send, null))
    }

    private fun print() {
        val f = file ?: return
        val name = fileName
        val pm = getSystemService(PRINT_SERVICE) as PrintManager
        pm.print(name, object : PrintDocumentAdapter() {
            override fun onLayout(
                old: PrintAttributes?, new: PrintAttributes?, cancel: CancellationSignal?,
                cb: LayoutResultCallback, extras: Bundle?
            ) {
                if (cancel?.isCanceled == true) {
                    cb.onLayoutCancelled()
                    return
                }
                cb.onLayoutFinished(
                    PrintDocumentInfo.Builder(name)
                        .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                        .build(), true
                )
            }

            override fun onWrite(
                pages: Array<out PageRange>?, dest: ParcelFileDescriptor,
                cancel: CancellationSignal?, cb: WriteResultCallback
            ) {
                try {
                    FileInputStream(f).use { i ->
                        FileOutputStream(dest.fileDescriptor).use { o -> i.copyTo(o) }
                    }
                    cb.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    cb.onWriteFailed(e.message)
                }
            }
        }, null)
    }
}
